package com.kevin.polinelainfo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ProduksiTanamanPangan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produksi_tanaman_pangan);
    }
}