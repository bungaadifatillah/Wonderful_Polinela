package com.kevin.polinelainfo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TeknikProduksiTanamanOrganik extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teknik_produksi_tanaman_organik);
    }
}